# Qartpay NodeJs Library

### Demo
```sh
node server.js
```
